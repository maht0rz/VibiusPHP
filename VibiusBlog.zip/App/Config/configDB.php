<?php

class configDB{
	
		public static $type = "mysql";
		public static $host = "localhost";
		public static $dbname = "mydb";
		public static $username = "root";
		public static $password = "root";

}