<?php

$lang = array(
'YourSelector' => 'translatedString',
'Login' => 'Prihlasenie',
'Register' => 'Registracia'
);