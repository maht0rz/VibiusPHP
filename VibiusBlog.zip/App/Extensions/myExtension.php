<?php

class myExtension{

	public static function myFunction(){
		echo "I am an extension method!";
	}
}