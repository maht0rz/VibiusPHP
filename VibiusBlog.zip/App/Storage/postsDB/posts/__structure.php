<?php

$structure = array('title' => '','text' => '','date' => '');