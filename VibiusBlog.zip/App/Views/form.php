<div class="container">
	<div class="row">
		<div class="col-xs-12 col-lg-6 col-lg-offset-3">
		<h2 class="text-center">Vibius Blog App</h2>
		</div>
		<div class="col-xs-12 col-lg-6 col-lg-offset-3">
			
			<form action="<?=$add?>" method="post">
			<label>Title</label>
			<input type="text" name="title" class="form-control">
			<label>Text</label>	
			<textarea class="form-control" name="text"></textarea>
			<label></label>
			<input type="submit" class="form-control btn btn-primary">
			</form>
		</div>

		
		

		
		