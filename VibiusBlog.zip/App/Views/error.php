<div class="container">
	<div class="row">
	<br>
		<div class="col-xs-12 col-lg-6 col-lg-offset-3">
			<div class="panel panel-lg">
				<div class="panel panel-default">
				  <div class="panel-body">
				    <h4 class="text-center">Oops! Something went wrong!</h4>

				    <a href="<?php echo URL::base(); ?>" class="form-control btn btn-primary">Go back to home page</a>
				  </div>
			</div>