	<div class="col-xs-12 col-lg-6 col-lg-offset-3 posts">
		<div class="well well-lg">
			<h2><strong><?=$title?></strong><small><?=$date?></small></h2>
			<p><?=$text?></p>
			<a href="<?=$url?>" class="form-control btn btn-default">View post / Go back</a>
		</div>
	</div>