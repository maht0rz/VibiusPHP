<?php

class welcomeController{
	
	public static function welcomeFunction($args){
		
		View::make('welcomeView');
	}
	
}
