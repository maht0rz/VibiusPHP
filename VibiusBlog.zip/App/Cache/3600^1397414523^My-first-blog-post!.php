	<div class="col-xs-12 col-lg-6 col-lg-offset-3 posts">
		<div class="well well-lg">
			<h2><strong>My first blog post!</strong><small>2014-04-13</small></h2>
			<p>Vestibulum ut egestas est. Morbi ultricies, magna a ornare molestie, nisl tellus aliquam tellus, nec feugiat justo sapien vel nibh. Sed elit justo, aliquam ut cursus non, porttitor vitae diam. Curabitur tristique nibh sit amet lacus dignissim, in egestas urna aliquet. Aenean bibendum magna et tellus eleifend, quis malesuada sapien facilisis. Mauris quis lacinia sapien. Quisque id odio pellentesque eros varius condimentum. Cras pharetra vestibulum lorem ac gravida. Duis turpis enim, fringilla a justo quis, ultricies malesuada lacus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
			<a href="http://localhost/Blog/" class="form-control btn btn-default">View post / Go back</a>
		</div>
	</div>			</div>
		</div>
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="http://localhost/Blog/assets/js/bootstrap.min.js"></script>
  </body>
</html>